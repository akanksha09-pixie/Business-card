import os
import threading
import time
from datetime import datetime
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, text

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "mysql+pymysql://root:password@localhost:3306/jagrukrail")
engine = create_engine(DATABASE_URL, pool_pre_ping=True, pool_recycle=1800)

app = FastAPI(title="JagrukRail RailSafe AI API", version="2.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ResolveAlertRequest(BaseModel):
    officer_id: int = Field(gt=0)
    action_taken: str = Field(min_length=2, max_length=5000)
    remarks: str = Field(min_length=2, max_length=5000)


def db_ok():
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return True
    except Exception:
        return False


@app.get("/health")
def health():
    return {"status": "online", "database_connected": db_ok()}


@app.get("/api/dashboard/stats")
def dashboard_stats():
    with engine.connect() as conn:
        stations = conn.execute(text("SELECT COUNT(*) FROM stations WHERE active=1")).scalar() or 0
        active = conn.execute(text("SELECT COUNT(*) FROM alerts WHERE status='ACTIVE'")).scalar() or 0
        critical = conn.execute(text("SELECT COUNT(*) FROM alerts WHERE status='ACTIVE' AND severity='CRITICAL'")).scalar() or 0
        detections = conn.execute(text("SELECT COUNT(*) FROM detection_events WHERE detected_at >= NOW() - INTERVAL 24 HOUR")).scalar() or 0
        avg_response = conn.execute(text("""
            SELECT AVG(TIMESTAMPDIFF(SECOND, detected_at, resolved_at))
            FROM alerts WHERE resolved_at IS NOT NULL
        """)).scalar()
    return {
        "stations_monitored": int(stations),
        "active_alerts": int(active),
        "critical_incidents": int(critical),
        "persons_detected": int(detections),
        "average_response_seconds": round(float(avg_response), 2) if avg_response is not None else None,
    }


@app.get("/api/alerts")
def get_alerts(status: Optional[str] = Query(None)):
    where = ""
    params = {}
    if status:
        where = "WHERE a.status=:status"
        params["status"] = status.upper()
    with engine.connect() as conn:
        rows = conn.execute(text(f"""
            SELECT a.id, a.camera_id, c.name AS camera_name, s.name AS station_name,
                   a.object_type, a.confidence, a.severity, a.status,
                   a.detected_at, a.escalated_at, a.resolved_at,
                   a.resolved_by, o.name AS officer_name
            FROM alerts a
            LEFT JOIN cameras c ON c.id=a.camera_id
            LEFT JOIN stations s ON s.id=c.station_id
            LEFT JOIN officers o ON o.id=a.resolved_by
            {where}
            ORDER BY a.detected_at DESC LIMIT 200
        """), params).mappings().all()
    return [dict(r) for r in rows]


@app.get("/api/incidents")
def get_incidents(limit: int = Query(200, ge=1, le=500)):
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT a.id, a.camera_id, c.name AS camera_name, s.name AS station_name,
                   a.object_type, a.confidence, a.severity, a.status,
                   a.detected_at, a.escalated_at, a.resolved_at,
                   o.name AS officer_name, o.office_id,
                   a.action_taken, a.remarks,
                   CASE WHEN a.resolved_at IS NOT NULL
                        THEN TIMESTAMPDIFF(SECOND,a.detected_at,a.resolved_at) END AS response_time_seconds
            FROM alerts a
            LEFT JOIN cameras c ON c.id=a.camera_id
            LEFT JOIN stations s ON s.id=c.station_id
            LEFT JOIN officers o ON o.id=a.resolved_by
            ORDER BY a.detected_at DESC LIMIT :limit
        """), {"limit": limit}).mappings().all()
    return [dict(r) for r in rows]


@app.get("/api/officers")
def get_officers():
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT o.id, o.name, o.office_id,
                   COUNT(a.id) AS handled_alerts,
                   COALESCE(SUM(CASE WHEN a.status='RESOLVED' THEN 1 ELSE 0 END),0) AS resolved_alerts,
                   AVG(CASE WHEN a.resolved_at IS NOT NULL
                       THEN TIMESTAMPDIFF(SECOND,a.detected_at,a.resolved_at) END) AS avg_response_seconds
            FROM officers o
            LEFT JOIN alerts a ON a.resolved_by=o.id
            WHERE o.active=1
            GROUP BY o.id,o.name,o.office_id
            ORDER BY o.name
        """)).mappings().all()
    result=[]
    for r in rows:
        handled=int(r["handled_alerts"] or 0)
        resolved=int(r["resolved_alerts"] or 0)
        result.append({
            "id": r["id"], "name": r["name"], "office_id": r["office_id"],
            "handled_alerts": handled,
            "accidents_prevented": resolved,
            "average_response_seconds": round(float(r["avg_response_seconds"]),2) if r["avg_response_seconds"] is not None else None,
            "resolution_rate": round((resolved/handled)*100,1) if handled else None,
        })
    return result


@app.get("/api/analytics/alerts-by-day")
def alerts_by_day(days: int = Query(7, ge=1, le=90)):
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT DATE(detected_at) AS day, COUNT(*) AS alerts
            FROM alerts
            WHERE detected_at >= DATE_SUB(CURDATE(), INTERVAL :days DAY)
            GROUP BY DATE(detected_at)
            ORDER BY day
        """), {"days": days}).mappings().all()
    return [{"date": str(r["day"]), "alerts": int(r["alerts"])} for r in rows]


@app.get("/api/cameras")
def get_cameras():
    with engine.connect() as conn:
        rows=conn.execute(text("""
            SELECT c.id,c.name,c.rtsp_url,c.active,s.name AS station_name,s.code AS station_code
            FROM cameras c JOIN stations s ON s.id=c.station_id
            ORDER BY c.id
        """)).mappings().all()
    # Never expose RTSP credentials in the browser.
    return [{k:v for k,v in dict(r).items() if k != "rtsp_url"} for r in rows]


@app.get("/api/cameras/{camera_id}/stream")
def camera_stream(camera_id: int):
    # A direct MJPEG proxy can be added if your authorized camera exposes MJPEG.
    # RTSP is intentionally not sent to the browser; production deployments should
    # use a server-side transcoder (FFmpeg/GStreamer/WebRTC) for browser playback.
    raise HTTPException(501, "Browser stream proxy is not configured. Connect the authorized camera through your approved video gateway/WebRTC service.")


@app.post("/api/alerts/{alert_id}/resolve")
def resolve_alert(alert_id: int, data: ResolveAlertRequest):
    with engine.begin() as conn:
        alert=conn.execute(text("SELECT id,status FROM alerts WHERE id=:id FOR UPDATE"), {"id":alert_id}).mappings().first()
        if not alert:
            raise HTTPException(404,"Alert not found")
        if alert["status"] != "ACTIVE":
            raise HTTPException(409,"This alert is no longer active")
        officer=conn.execute(text("SELECT id FROM officers WHERE id=:id AND active=1"), {"id":data.officer_id}).first()
        if not officer:
            raise HTTPException(400,"Officer not found or inactive")
        conn.execute(text("""
            UPDATE alerts SET status='RESOLVED', resolved_by=:officer_id,
            resolved_at=NOW(), action_taken=:action_taken, remarks=:remarks
            WHERE id=:id
        """), {"id":alert_id,"officer_id":data.officer_id,"action_taken":data.action_taken,"remarks":data.remarks})
    return {"success":True,"message":"Action Taken Report recorded successfully"}


@app.post("/api/internal/alerts")
def create_alert_internal(camera_id: int, object_type: str, confidence: float):
    """Endpoint for the approved server-side detector. Not intended for public exposure."""
    with engine.begin() as conn:
        existing=conn.execute(text("""
            SELECT id FROM alerts WHERE camera_id=:camera_id AND status='ACTIVE'
            ORDER BY detected_at DESC LIMIT 1
        """), {"camera_id":camera_id}).first()
        if existing:
            conn.execute(text("""
                INSERT INTO detection_events(alert_id,camera_id,object_type,confidence,detected_at)
                VALUES(:alert_id,:camera_id,:object_type,:confidence,NOW())
            """), {"alert_id":existing[0],"camera_id":camera_id,"object_type":object_type,"confidence":confidence})
            return {"alert_id":existing[0],"new":False}
        result=conn.execute(text("""
            INSERT INTO alerts(camera_id,object_type,confidence,severity,status,detected_at)
            VALUES(:camera_id,:object_type,:confidence,'WARNING','ACTIVE',NOW())
        """), {"camera_id":camera_id,"object_type":object_type,"confidence":confidence})
        alert_id=result.lastrowid
        conn.execute(text("""
            INSERT INTO detection_events(alert_id,camera_id,object_type,confidence,detected_at)
            VALUES(:alert_id,:camera_id,:object_type,:confidence,NOW())
        """), {"alert_id":alert_id,"camera_id":camera_id,"object_type":object_type,"confidence":confidence})
    return {"alert_id":alert_id,"new":True}


# Escalation is deliberately time-based only as a backend safeguard. For a real
# safety deployment, the detector must continuously confirm the tracked hazard is
# still inside the configured track ROI before this transition is made.
def escalation_worker():
    while True:
        try:
            with engine.begin() as conn:
                conn.execute(text("""
                    UPDATE alerts
                    SET severity='CRITICAL', escalated_at=NOW()
                    WHERE status='ACTIVE' AND severity='WARNING'
                      AND detected_at <= NOW() - INTERVAL 3 SECOND
                """))
        except Exception as exc:
            print("Escalation worker:", exc)
        time.sleep(0.5)


threading.Thread(target=escalation_worker, daemon=True).start()
