# JagrukRail — RailSafe AI

A real-data-first railway track hazard monitoring dashboard.

## Flow

Authorized camera/detection system → track-zone detection → MySQL alert → 0–3 second warning → critical escalation after 3 seconds if the alert remains active → officer verifies camera and takes action → exactly 3-field Action Taken Report → MySQL → officer scorecard.

## Important

This repository does **not** contain demo incidents, fake officer statistics, fake camera footage, or invented railway data. The UI remains usable with empty database tables, but real operational data must be inserted by an authorized deployment team.

A browser cannot safely play an RTSP stream directly. The backend therefore does not expose RTSP URLs. For real camera playback, connect the authorized cameras to an approved video gateway/transcoder/WebRTC service and point the frontend to that service.

Do not connect this prototype directly to railway signalling/interlocking/train-control systems. Hardware lights/sirens and operational restrictions require approved railway safety interfaces and procedures.

## 1. MySQL

Run:

```sql
SOURCE backend/schema.sql;
```

Then insert your authorized station, camera and officer records. Example shape:

```sql
INSERT INTO stations(name,code,location) VALUES ('YOUR STATION','CODE','AUTHORIZED LOCATION');
INSERT INTO officers(name,office_id) VALUES ('AUTHORIZED OFFICER','OFFICE-ID');
INSERT INTO cameras(station_id,name,rtsp_url) VALUES (1,'TRACK CAMERA 01','rtsp://AUTHORIZED_SERVER/STREAM');
```

Replace the example values with real authorized records.

## 2. Backend

```bash
cd backend
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env   # Windows
# or: cp .env.example .env
```

Edit `.env` with your MySQL credentials, then:

```bash
uvicorn main:app --reload --port 8000
```

Health check: `http://localhost:8000/health`

## 3. Frontend

```bash
cd frontend
npm install
copy .env.example .env   # Windows
# or: cp .env.example .env
npm run dev
```

Open the Vite URL shown in the terminal.

## 4. Detection integration

The dashboard API accepts an internal detector alert at `/api/internal/alerts`. Your approved server-side YOLO/OpenCV/track-zone service should call it when a tracked hazard enters the configured track zone. For a true 3-second rule, the detector must continuously confirm that the same hazard remains in the track zone before escalation; a simple clock alone is not sufficient for a safety-certified deployment.

The current officer "accidents prevented" field counts resolved hazards. It should only be presented as verified collision prevention after integrating an approved train movement/arrival source.
